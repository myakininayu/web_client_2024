import Table from 'react-bootstrap/Table';
import Product from './Product/Product';

function Products() {
  return (
    <div>
      <Table responsive="sm">
        <thead>
          <tr>
            <th>#</th>
            <th>Название</th>
            <th>Категория</th>
            <th>Фото</th>
            <th>Цена</th>
            <th>Настройки</th>
          </tr>
        </thead>
        <tbody>
          <Product dish={{id:1, name:"Карбонара", category:"Паста", photo:"./", price:"500"}}/>
          <Product dish={{id:2, name:"Пицца Маргарита", category:"Пицца", photo:"./", price:"550"}}/>
          <Product dish={{id:3, name:"Торт Наполеон", category:"Десерты", photo:"./", price:"890"}}/>
          <Product dish={{id:4, name:"Панна котта", category:"Десерты", photo:"./", price:"100"}}/>
          
        </tbody>
      </Table>  
    </div>
  );
}

export default Products;