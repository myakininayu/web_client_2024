import Button from 'react-bootstrap/Button';

function Product(props) {
  return (
    <tr>
        <td>{props.dish.id}</td>
        <td>{props.dish.name}</td>
        <td>{props.dish.category}</td>
        <td>{props.dish.photo}</td>
        <td>{props.dish.price}₽</td>
        <td>
          <Button variant="primary">Редактировать</Button>
          <Button variant="danger">Удалить</Button>
        </td>
    </tr>
  );
}

export default Product;