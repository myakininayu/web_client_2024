import {create} from "zustand"

const useStore = create((set) => ({
    products: [
        {id:1, name:"Карбонара", category:"Паста", photo:"./img/pasta.jpg", price:"500"},
        {id:2, name:"Пицца Маргарита", category:"Пицца", photo:"./img/pizza.png", price:"550"},
        {id:3, name:"Торт Наполеон", category:"Десерты", photo:"./img/tort.jpg", price:"890"},
        {id:4, name:"Панна котта", category:"Десерты", photo:"./img/panna_kotta.webp", price:"100"}]
}))

export default useStore