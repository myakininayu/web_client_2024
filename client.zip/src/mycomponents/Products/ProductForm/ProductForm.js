import { Button, InputGroup } from 'react-bootstrap';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';

function ProductForm() {
  return (
    <Form className='m-3'>
        <Form.Group as={Row} className="mb-3">
        <Form.Label column sm="2">
          №
        </Form.Label>
        <Col sm="10">
          <Form.Control plaintext readOnly defaultValue="" />
        </Col>
      </Form.Group>

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm="2">
          Название
        </Form.Label>
        <Col sm="10">
          <Form.Control />
        </Col>
      </Form.Group>

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm="2">
          Категория
        </Form.Label>
        <Col sm="10">
          <Form.Control />
        </Col>
      </Form.Group>

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm="2">
          Фото
        </Form.Label>
        <Col sm="10">
          <Form.Control />
        </Col>
      </Form.Group>

      <Form.Group as={Row} className="mb-3">
        <Form.Label column sm="2">
          Цена
        </Form.Label>
        <Col sm="10">
          <Form.Control />
        </Col>
      </Form.Group>

      <Button variant="primary" >Сохранить</Button>
    </Form>
  );
}

export default ProductForm;